from flask import Flask, render_template, request, jsonify
from urllib.parse import urlparse
import re

app = Flask(__name__)

# Transparent, manually designed weights (not a trained ML model).
WEIGHTS = {
    "urgency": 10,
    "prize": 20,
    "payment": 25,
    "sensitive_info": 30,
    "suspicious_url": 20,
    "impersonation": 15,
    "threat": 15,
}

PATTERNS = {
    "urgency": {
        "label": "Urgent or pressuring language",
        "terms": [
            "immediately", "urgent", "act now", "within 24 hours",
            "limited time", "today only", "account will be blocked",
            "last warning", "verify now"
        ],
        "weight_key": "urgency",
        "explanation": "The message pressures the recipient to act quickly."
    },
    "prize": {
        "label": "Unexpected prize or reward",
        "terms": [
            "you have won", "congratulations", "claim your prize",
            "winner", "won a prize", "cash reward", "lottery"
        ],
        "weight_key": "prize",
        "explanation": "Unexpected prizes and rewards can be used to lure people into scams."
    },
    "payment": {
        "label": "Payment or upfront fee request",
        "terms": [
            "processing fee", "pay now", "upfront fee", "send money",
            "transfer money", "pay a fee", "payment required",
            "gift card", "wire transfer"
        ],
        "weight_key": "payment",
        "explanation": "The message appears to request money or an upfront payment."
    },
    "sensitive_info": {
        "label": "Sensitive information request",
        "terms": [
            "otp", "one time password", "password", "pin number",
            "bank details", "card number", "cvv", "social security",
            "share your credentials", "account credentials"
        ],
        "weight_key": "sensitive_info",
        "explanation": "Requests for passwords, OTPs, PINs, or financial details are a warning sign."
    },
    "impersonation": {
        "label": "Possible organisation impersonation",
        "terms": [
            "bank support", "government department", "tax department",
            "customer care", "your bank", "account department",
            "official support", "police department"
        ],
        "weight_key": "impersonation",
        "explanation": "The message claims or appears to speak on behalf of an organisation."
    },
    "threat": {
        "label": "Threatening or coercive language",
        "terms": [
            "account suspended", "account blocked", "legal action",
            "arrest warrant", "you will be arrested", "penalty",
            "fine will be imposed", "service terminated"
        ],
        "weight_key": "threat",
        "explanation": "Threats or coercive consequences may be used to pressure the recipient."
    },
}

SCAM_RULES = [
    {
        "name": "Possible prize scam",
        "requires_any": ["prize"],
        "requires_all": ["payment"],
        "conclusion": "Possible prize scam",
        "explanation": "An unexpected prize/reward is combined with a payment request."
    },
    {
        "name": "Possible phishing attempt",
        "requires_any": ["suspicious_url"],
        "requires_all": ["sensitive_info"],
        "conclusion": "Possible phishing attempt",
        "explanation": "A suspicious-looking URL is combined with a request for sensitive information."
    },
    {
        "name": "Possible high-pressure scam",
        "requires_all": ["urgency", "payment"],
        "conclusion": "Possible high-pressure payment scam",
        "explanation": "Urgency is combined with a request for money."
    },
    {
        "name": "Possible impersonation scam",
        "requires_all": ["impersonation", "sensitive_info"],
        "conclusion": "Possible impersonation scam",
        "explanation": "An organisation reference is combined with a request for sensitive information."
    },
    {
        "name": "Possible threatening scam",
        "requires_all": ["threat", "sensitive_info"],
        "conclusion": "Possible threat-based scam",
        "explanation": "Threatening language is combined with a request for sensitive information."
    },
]

def extract_urls(text):
    candidates = re.findall(r'(?i)\b(?:https?://|www\.)[^\s<>"\']+', text)
    cleaned = []
    for item in candidates:
        cleaned.append(item.rstrip(".,!?;:)]}"))
    return cleaned

def inspect_url(raw_url):
    url = raw_url.strip()
    normalised = url if url.lower().startswith(("http://", "https://")) else "http://" + url
    parsed = urlparse(normalised)
    host = (parsed.hostname or "").lower()
    findings = []

    if not host:
        return {"url": url, "findings": ["Could not parse this URL."], "suspicious": True}

    if parsed.scheme == "http":
        findings.append("Uses HTTP rather than HTTPS.")
    if "@" in parsed.netloc:
        findings.append("Contains an @ symbol in the URL authority.")
    if re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", host):
        findings.append("Uses an IP address instead of a conventional domain name.")
    if host.startswith("xn--") or ".xn--" in host:
        findings.append("Contains an internationalised/punycode domain label.")
    if len(url) > 100:
        findings.append("Unusually long URL.")
    if host.count("-") >= 3:
        findings.append("Domain contains several hyphens.")
    if host.count(".") >= 4:
        findings.append("Domain has many subdomain levels.")
    if any(token in host for token in ["login-secure", "verify-account", "free-gift", "claim-prize"]):
        findings.append("Domain contains wording often used in deceptive links.")
    if not findings:
        findings.append("No basic structural warning signs were found; this does not prove the URL is safe.")

    suspicious = any(
        f != "No basic structural warning signs were found; this does not prove the URL is safe."
        for f in findings
    )
    return {"url": url, "findings": findings, "suspicious": suspicious}

def analyse_text(text, extra_url=""):
    content = (text or "").strip()
    all_urls = extract_urls(content)
    # In URL-only mode, also accept a bare domain such as example.com.
    if content and not all_urls and not any(ch.isspace() for ch in content) and "." in content:
        all_urls.append(content)
    if extra_url and extra_url.strip():
        all_urls.extend(extract_urls(extra_url))
        if not extract_urls(extra_url):
            all_urls.append(extra_url.strip())

    url_results = []
    seen = set()
    for url in all_urls:
        if url not in seen:
            seen.add(url)
            url_results.append(inspect_url(url))

    facts = set()
    indicators = []
    lowered = content.lower()

    for key, info in PATTERNS.items():
        matched = [term for term in info["terms"] if term in lowered]
        if matched:
            facts.add(key)
            indicators.append({
                "key": key,
                "label": info["label"],
                "matched": matched[:4],
                "points": WEIGHTS[info["weight_key"]],
                "explanation": info["explanation"],
            })

    if any(result["suspicious"] for result in url_results):
        facts.add("suspicious_url")
        indicators.append({
            "key": "suspicious_url",
            "label": "URL structure warning",
            "matched": [r["url"] for r in url_results if r["suspicious"]],
            "points": WEIGHTS["suspicious_url"],
            "explanation": "At least one URL has a basic structural characteristic worth checking."
        })

    # Forward chaining: repeatedly apply rules while new conclusions are derived.
    conclusions = []
    known_facts = set(facts)
    changed = True
    while changed:
        changed = False
        for rule in SCAM_RULES:
            if rule["conclusion"] in conclusions:
                continue
            any_ok = (not rule["requires_any"]) or any(x in known_facts for x in rule["requires_any"])
            all_ok = all(x in known_facts for x in rule["requires_all"])
            if any_ok and all_ok:
                conclusions.append(rule["conclusion"])
                known_facts.add(rule["conclusion"])
                changed = True

    # Weighted score: count each indicator once and cap at 100.
    raw_score = sum(WEIGHTS[item["key"]] for item in indicators if item["key"] in WEIGHTS)
    score = min(raw_score, 100)

    if score >= 70:
        level = "Very high"
        level_class = "very-high"
    elif score >= 45:
        level = "High"
        level_class = "high"
    elif score >= 20:
        level = "Moderate"
        level_class = "moderate"
    else:
        level = "Low"
        level_class = "low"

    if conclusions:
        category = conclusions[0] if len(conclusions) == 1 else "Multiple possible scam patterns"
    elif facts:
        category = "Suspicious indicators detected"
    else:
        category = "No known warning signs detected"

    recommendations = []
    if "sensitive_info" in facts:
        recommendations.append("Never share OTPs, passwords, PINs, or full payment-card details in response to an unsolicited message.")
    if "payment" in facts:
        recommendations.append("Do not pay an unexpected fee until you independently verify the request.")
    if "suspicious_url" in facts:
        recommendations.append("Avoid opening the link. Visit the organisation's official website by typing its address yourself.")
    if "urgency" in facts or "threat" in facts:
        recommendations.append("Pause before acting; verify the claim using a trusted, independent contact method.")
    if not recommendations:
        recommendations.append("If the message is unexpected, verify the sender through an independent trusted channel.")

    return {
        "score": score,
        "level": level,
        "level_class": level_class,
        "category": category,
        "indicators": indicators,
        "conclusions": conclusions,
        "url_results": url_results,
        "recommendations": recommendations,
        "text": content,
    }

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/analyse", methods=["POST"])
def analyse():
    data = request.get_json(silent=True) or request.form
    text = data.get("message", "")
    url = data.get("url", "")
    if not str(text).strip() and not str(url).strip():
        return jsonify({"error": "Enter a message, email text, or URL to analyse."}), 400
    result = analyse_text(str(text), str(url))
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)
