const form = document.getElementById("analysis-form");
const messageInput = document.getElementById("message");
const urlInput = document.getElementById("url");
const inputLabel = document.getElementById("input-label");
const urlExtra = document.getElementById("url-extra");
const charCount = document.getElementById("char-count");
const formError = document.getElementById("form-error");
const analyseBtn = document.getElementById("analyse-btn");
const resultsSection = document.getElementById("results-section");
let currentMode = "message";

const samples = {
  message: "Congratulations! You have won ₹50,000. Pay a processing fee immediately to claim your prize. Share your bank details to complete verification.",
  email: "Subject: Urgent account verification required\n\nDear Customer, your bank account will be blocked today. Verify now using this link and provide your password and OTP to avoid account suspension.",
  url: "http://login-secure.example.com/verify-account"
};

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((item) => {
      item.classList.remove("active");
      item.setAttribute("aria-selected", "false");
    });
    tab.classList.add("active");
    tab.setAttribute("aria-selected", "true");
    currentMode = tab.dataset.mode;
    if (currentMode === "message") {
      inputLabel.textContent = "Paste a suspicious SMS or WhatsApp message";
      messageInput.placeholder = "Paste the message you want to check...";
      urlExtra.hidden = false;
    } else if (currentMode === "email") {
      inputLabel.textContent = "Paste the email text (including subject, if available)";
      messageInput.placeholder = "Paste the email content here...";
      urlExtra.hidden = false;
    } else {
      inputLabel.textContent = "Paste the URL you want to inspect";
      messageInput.placeholder = "https://example.com/verify";
      urlExtra.hidden = true;
    }
  });
});

messageInput.addEventListener("input", () => {
  charCount.textContent = `${messageInput.value.length} characters`;
  formError.hidden = true;
});

document.getElementById("sample-btn").addEventListener("click", () => {
  if (currentMode === "url") {
    messageInput.value = samples.url;
  } else {
    messageInput.value = samples[currentMode];
  }
  charCount.textContent = `${messageInput.value.length} characters`;
  formError.hidden = true;
});

document.getElementById("reset-btn").addEventListener("click", () => {
  form.reset();
  messageInput.value = "";
  urlInput.value = "";
  charCount.textContent = "0 characters";
  resultsSection.hidden = true;
  formError.hidden = true;
  window.scrollTo({ top: document.querySelector(".workspace").offsetTop - 15, behavior: "smooth" });
});

function createElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function renderIndicators(indicators) {
  const list = document.getElementById("indicator-list");
  list.replaceChildren();
  document.getElementById("indicator-count").textContent = `${indicators.length} indicator${indicators.length === 1 ? "" : "s"}`;
  if (!indicators.length) {
    list.append(createElement("div", "empty-state", "No configured warning indicators were matched. This does not guarantee that the message is safe."));
    return;
  }
  indicators.forEach((indicator) => {
    const item = createElement("div", "indicator-item");
    const main = createElement("div", "indicator-main");
    main.append(createElement("span", "indicator-check", "✓"));
    const copy = createElement("div");
    copy.append(createElement("h4", "", indicator.label));
    const matched = indicator.matched && indicator.matched.length ? `Matched: ${indicator.matched.join(", ")}. ` : "";
    copy.append(createElement("p", "", `${matched}${indicator.explanation}`));
    main.append(copy);
    item.append(main);
    item.append(createElement("span", "points", `+${indicator.points} pts`));
    list.append(item);
  });
}

function renderReasoning(conclusions) {
  const list = document.getElementById("reasoning-list");
  list.replaceChildren();
  document.getElementById("rule-count").textContent = `${conclusions.length} rule${conclusions.length === 1 ? "" : "s"} triggered`;
  if (!conclusions.length) {
    list.append(createElement("div", "empty-state", "No scam-category rule was triggered by the current indicators."));
    return;
  }
  conclusions.forEach((conclusion) => {
    const item = createElement("div", "reasoning-item");
    item.append(createElement("span", "reasoning-check", "✓"));
    const copy = createElement("div");
    copy.append(createElement("h4", "", conclusion));
    copy.append(createElement("p", "", "This conclusion was derived by applying the configured rule to the detected facts."));
    item.append(copy);
    list.append(item);
  });
}

function renderUrls(urlResults) {
  const card = document.getElementById("url-results-card");
  const list = document.getElementById("url-results-list");
  list.replaceChildren();
  card.hidden = !urlResults.length;
  urlResults.forEach((result) => {
    const item = createElement("div", "indicator-item");
    const main = createElement("div", "indicator-main");
    main.append(createElement("span", "indicator-check", result.suspicious ? "!" : "✓"));
    const copy = createElement("div");
    copy.append(createElement("h4", "", result.url));
    result.findings.forEach((finding) => copy.append(createElement("p", "", finding)));
    main.append(copy);
    item.append(main);
    item.append(createElement("span", `risk-badge ${result.suspicious ? "high" : "low"}`, result.suspicious ? "Check URL" : "No basic flag"));
    list.append(item);
  });
}

function renderResult(result) {
  document.getElementById("score").textContent = result.score;
  const badge = document.getElementById("risk-badge");
  badge.className = `risk-badge ${result.level_class}`;
  badge.textContent = `${result.level} indicator level`;
  const meter = document.getElementById("meter-fill");
  meter.style.width = `${result.score}%`;
  meter.style.background = result.level_class === "very-high" ? "#d94a65" : result.level_class === "high" ? "#e48b47" : result.level_class === "moderate" ? "#e0b34e" : "#18a999";
  document.getElementById("category").textContent = result.category;
  document.getElementById("category-description").textContent = result.conclusions.length
    ? "One or more configured reasoning rules matched the indicators found in the input."
    : result.indicators.length
      ? "Some warning signs were detected, but no configured scam-category rule fully matched."
      : "No configured warning signs were detected. Always verify unexpected requests independently.";
  renderIndicators(result.indicators);
  renderReasoning(result.conclusions);
  renderUrls(result.url_results);

  const recommendations = document.getElementById("recommendations");
  recommendations.replaceChildren();
  result.recommendations.forEach((recommendation) => recommendations.append(createElement("li", "", recommendation)));
  resultsSection.hidden = false;
  resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  formError.hidden = true;
  const message = messageInput.value.trim();
  const url = currentMode === "url" ? "" : urlInput.value.trim();
  const payload = { message, url };
  if (currentMode === "url" && message) payload.message = message;
  if (!message && !url) {
    formError.textContent = "Please enter a message, email, or URL first.";
    formError.hidden = false;
    return;
  }
  analyseBtn.disabled = true;
  analyseBtn.innerHTML = "<span>⌕</span> Analysing... <span class='btn-arrow'>…</span>";
  try {
    const response = await fetch("/analyse", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Unable to analyse this input.");
    renderResult(result);
  } catch (error) {
    formError.textContent = error.message || "Something went wrong. Check that the Flask server is running.";
    formError.hidden = false;
  } finally {
    analyseBtn.disabled = false;
    analyseBtn.innerHTML = "<span>⌕</span> Analyse for risks <span class='btn-arrow'>→</span>";
  }
});
