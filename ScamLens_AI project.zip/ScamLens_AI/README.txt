SCAMLENS AI — RUN INSTRUCTIONS
==============================

Project structure:
  ScamLens_AI/
    app.py
    requirements.txt
    README.txt
    templates/
      index.html
    static/
      style.css
      script.js

Requirements:
  Python 3.9+ recommended

Run on Windows:
  1. Extract the ScamLens_AI folder.
  2. Open Command Prompt or PowerShell inside the ScamLens_AI folder.
  3. (Optional) Create a virtual environment:
       python -m venv venv
       venv\Scripts\activate
  4. Install Flask:
       pip install -r requirements.txt
  5. Start the app:
       python app.py
  6. Open this address in your browser:
       http://127.0.0.1:5000

How it works:
  - HTML, CSS and JavaScript provide the frontend.
  - Flask/Python provides the backend.
  - Pattern matching extracts configured warning indicators.
  - Propositional-style facts and forward-chaining rules infer possible scam patterns.
  - A transparent weighted score summarises detected indicators.
  - URL checks inspect basic URL structure only; they do not visit URLs.

Important:
  This is a student prototype, not a production security product. The scoring weights
  and rules are manually configured and not validated fraud probabilities. It can miss
  scams or flag legitimate messages. Do not use the result as proof that a message is
  safe or fraudulent. The Flask debug server is for local development only.
